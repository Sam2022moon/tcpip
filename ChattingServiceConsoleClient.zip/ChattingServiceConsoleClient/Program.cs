﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChattingServiceConsoleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleClient a = new ConsoleClient();
            a.Run();
        }
    }
}
